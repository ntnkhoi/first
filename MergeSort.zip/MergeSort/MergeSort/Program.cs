﻿using System.Formats.Asn1;
using System.Globalization;

namespace MergeSort;
class Program
{
static public void MergeSort(int [] arr, int l, int r)
{
	if(l<r){
	int mid = l + (r-l)/2;
	MergeSort(arr, l, mid);
	MergeSort(arr, mid+1, r);
	Merge(arr,l,mid,r);
	}
}
static public void Merge(int [] arr, int l, int mid, int r)
{
	int [] temp = new int [r - l + 1]; 
	int i = l; int j = mid + 1; int k = 0;
    while(i <= mid && j <= r){
		if (arr[i] <= arr[j]) { temp[k++] = arr[i++]; }
		else { temp[k++] = arr[j++]; }
	}
	while(i <= mid) { temp[k++] = arr[i++]; }
	while(j <= r) { temp[k++] = arr[j++]; }
    for (i = 0; i < temp.Length; i++)
    {
        arr[l+i] = temp[i];
    }
}

    
    static void Main(string[] args)
    {
        int[] arr = { 21,16,9,7,3,2,1};
        Console.WriteLine("Mảng ban đầu:");
        Console.WriteLine(string.Join(" ", arr));

        MergeSort(arr, 0, arr.Length - 1);

        Console.WriteLine("\nMảng sau khi sắp xếp bằng Merge Sort:");
        Console.WriteLine(string.Join(" ", arr));
    }
}
